<?php
/* 
Plugin Name: TC Meta Box
Plugin URI: http://www.tutorclip.com
Description: เขียน Plugin meta box
Version: 1.0
Author: Weerawat Chaleuiphot
Author URI:  http://www.tutorclip.com
License: GPL2
*/

add_action('add_meta_boxes','tc_add_metabox');

add_action('save_post','tc_save_metabox');

function tc_add_metabox(){
	add_meta_box('tc_youtube','YouTube Video Link','tc_youtube_handler','post');	
}

function tc_youtube_handler(){
	$value = get_post_custom($post->ID);
	$youtube_link = esc_attr($value['tc_youtube'][0]);
	echo'<label for="tc_youtube">YouTube Video Link URL : </lable><input type="text" id="tc_youtube" name="tc_youtube" value="'.$youtube_link.'" />';
}

function tc_save_metabox($post_id){
	if(defined('DOING_AUTOSAVE') && DOING_AUTOSAVE){
		return;
	}
	
	if(!current_user_can('edit_post')){
		return;
	}
	
	if(isset($_POST['tc_youtube'])){
		update_post_meta($post_id,'tc_youtube',esc_url($_POST['tc_youtube']));
	}  
}

?>