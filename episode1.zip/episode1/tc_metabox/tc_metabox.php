<?php
/* 
Plugin Name: TC Meta Box
Plugin URI: http://www.tutorclip.com
Description: เขียน Plugin meta box
Version: 1.0
Author: Weerawat Chaleuiphot
Author URI:  http://www.tutorclip.com
License: GPL2
*/

add_action('add_meta_boxes','tc_add_metabox');

add_action('save_post','tc_save_metabox');

function tc_add_metabox(){
	add_meta_box('tc_metabox','Meta Box Customs','tc_metabox_handler','post');	
}

function tc_metabox_handler(){
	$value = get_post_custom($post->ID);
	$Data_link = esc_attr($value['tc_metabox'][0]);
	echo'<label for="tc_metabox">Link URL : </lable><input type="text" id="tc_metabox" name="tc_metabox" placeholder="http://www.website.com" value="'.$Data_link.'" />';
}

function tc_save_metabox($post_id){
	if(defined('DOING_AUTOSAVE') && DOING_AUTOSAVE){
		return;
	}
	
	if(!current_user_can('edit_post')){
		return;
	}
	
	if(isset($_POST['tc_metabox'])){
		update_post_meta($post_id,'tc_metabox',esc_url($_POST['tc_metabox']));
	}  
}

?>