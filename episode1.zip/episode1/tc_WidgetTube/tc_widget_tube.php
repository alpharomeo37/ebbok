<?php
/* 
Plugin Name: TC Widget Tube
Plugin URI: http://www.tutorclip.com
Description: เขียน  Widget ในการดึง Clip VDO จาก  Youtube มาแสดง
Version: 1.0
Author: Weerawat Chaleuiphot
Author URI:  http://www.tutorclip.com
License: GPL2
*/

// register widgets
add_action('widgets_init','tc_youtube_widget_init');

// register widget here
function tc_youtube_widget_init(){
	register_widget(tc_youtube_widget);
}

// Widget Class
class tc_youtube_widget extends WP_Widget{
		function tc_youtube_widget(){
			$widget_options = array(
				'classname' => 'tc_class',//CSS
				'description' => 'Show YouTube Video From Post Meta Data'
			);
			$this->WP_Widget('tc_youtube_id','YouTube Video',$widget_options);
		}
		
		// Show Widget in Widget Area
		function form($instance){
			$defaults = array(
				'title' => 'YouTube Video',
				'url' => 'Link Clip'
			);
			$instance = wp_parse_args((array) $instance,$defaults);
			$title = esc_attr($instance['title']);
			$url = $instance['url'];
			
			echo '<p>Title <input type="text" class="widefat" name="'.$this->get_field_name('title').'" value="'.$title.'" /></p>';
			echo '<p>URL <input type="text" class="widefat" name="'.$this->get_field_name('url').'" value="'.$url.'" /></p>';
		}
		
		// Save form in Widget
		function update($new_instance,$old_instance){
			
			$instance = $old_instance;
			$instance['title'] = strip_tags($new_instance['title']);
			$instance['url'] = strip_tags($new_instance['url']);
			
			return $instance;
		}
		
		// Show Widget in website
		function widget($args,$instance){
			
			extract($args);
		
			$title = apply_filters('widget_title',$instance['title']);
			$url = $instance['url'];
			// Get YouTube Video
			parse_str(parse_url($url,PHP_URL_QUERY),$my_array_of_vars);		
			$result_url = '<iframe width="200" height="200" frameborder="0" frameborder="0" allowfullscreen src="http://www.youtube.com/embed/'.$my_array_of_vars['v'].'"></iframe>';
			
			echo $before_widget;
			echo $before_title.$title.$after_title;					
			echo  $result_url;		
			echo $after_title;
										
		}		
}

?>