<?php
/* 
Plugin Name: TC Shortcode Attribute
Plugin URI: http://www.tutorclip.com
Description: เขียน Plugin แบบ  Short Code Attribute Function
Version: 1.0
Author: Weerawat Chaleuiphot
Author URI:  http://www.tutorclip.com
License: GPL2
*/
	 add_shortcode('myTwiitter','tc_shortcode_atts');
	
	function tc_shortcode_atts($atts,$content){
		$defaults = shortcode_atts(
					array(
						'username' => !empty($username)? $username :'thegrammys',
						'content' =>  !empty($content)? $content : 'Please Follow me now !! ',
						'colors' => !empty($atts['colors']) ? $atts['colors'] : 'green'
					),$atts);
							
		return '<a href="https://twitter.com/'.$defaults['username'].'">'.
			   '<font color='.$defaults['colors'].'>'.$defaults['content'].'</font></a>'; 
	} 
/*========== รูปแบบการใช้ Shortcode_atts ของ Word Press version 3.6 เป็นต้นไป  ============================= */	

	/* add_shortcode('myTwiitter','tc_shortcode_atts');
	function tc_shortcode_atts($atts,$content){
		$defaults = shortcode_atts(
					array(
						'username' => !empty($username)? $username :'thegrammys',
						'content' =>  !empty($content)? $content : 'Please Follow me now !! ',
						'colors' => !empty($atts['colors']) ? $atts['colors'] : 'green'
					),$atts,'myTwiitter');
							
		return '<a href="https://twitter.com/'.$defaults['username'].'">'.
			   '<font color='.$defaults['colors'].'>'.$defaults['content'].'</font></a>'; 
	} */
	
?>