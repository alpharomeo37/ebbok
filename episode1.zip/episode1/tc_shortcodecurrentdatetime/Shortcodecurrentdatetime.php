<?php
/* 
Plugin Name: TC Shortcode Current Date Time
Plugin URI: http://www.tutorclip.com
Description: เขียน Plugin แบบ  Short Code
Version: 1.0
Author: Weerawat Chaleuiphot
Author URI:  http://www.tutorclip.com
License: GPL2
*/
    add_shortcode('currentdatetime','tc_currentdatetime');
	
	function tc_currentdatetime(){
		return  'Current Date Time : '.date("Y-m-d H:i:s");
	}
?>
