<?php
/* 
Plugin Name: TC Shortcode Parameter
Plugin URI: http://www.tutorclip.com
Description: เขียน Plugin แบบ  Short Code Attribute Parameter
Version: 1.0
Author: Weerawat Chaleuiphot
Author URI:  http://www.tutorclip.com
License: GPL2
*/
    add_shortcode('product','tc_shortcode_ptr');
	
	function tc_shortcode_ptr($attr,$content){
		if(!isset($attr['category'])) $attr['category'] = '/cat/1/หนังสือทั่วไป/';
		else if ($attr['category'] == 'นิตยสารแมกกาซีน') $attr['category'] = '/cat/5/นิตยสาร_แมกกาซีน';
			 else $attr['category'] = '/cat/2/หนังสือพิมพ์/';
		return  '<a href="http://www.ebooks.in.th'.$attr['category'].'">ร้านขายหนังสือ Online ประเภท E-Book !!</a>'.$content;
	}
?>
