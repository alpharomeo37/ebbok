<?php
/* 
Plugin Name: TC Loop
Plugin URI: http://www.tutorclip.com
Description: เขียน Plugin โดยใช้ คำสั่งการแสดงแบบวนรอบ ( Loop)
Version: 1.0
Author: Weerawat Chaleuiphot
Author URI:  http://www.tutorclip.com
License: GPL2
*/

add_filter('the_content','tc_loop_related_post');

function tc_loop_related_post($content){
	
	if(!is_singular('post')){
		return $content;
	}
	
	$cate = get_the_terms(get_the_ID(),'category');
	$cateID = array();
	
	foreach($cate as $category){
		$cateID[] = $category->term_id;
	}
	
	$LoopObj = new WP_Query(array(
		'category_in' => $cateID,
		'post_per_page' => 3,
		'order by' => 'date' 
	));
	
	if($LoopObj->have_posts()){
		$content .= 'โพสที่เกี่ยวข้อง : <br/><ul>';
		while($LoopObj->have_posts()){
			$LoopObj->the_post();
			$content .='<li><a href="'.get_permalink().'">'.get_the_title().'</a></li>';
		}
		$content .= '</ul>';
	}
	wp_reset_query();
	
	return $content; 
};


?>