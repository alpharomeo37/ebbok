<?php
/*
 Plugin Name: TC Filter 
 Plugin URI: http://www.tutorclip.com
 Description: เขียน Plugin แบบ  Filter Hooks
 Version: 1.0
 Author: Weerawat Chaleuiphot
 Author URI:  http://www.tutorclip.com
 License: GPL2
 
*/

add_filter('the_title',function($content){
	return ucwords($content);
});

add_filter('the_content',function($content){
	return $content.' this post at date : '.date('Y-M-d');
});
?>