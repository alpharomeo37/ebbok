<?php
/* 
Plugin Name: TC Shortcode Google Map
Plugin URI: http://www.tutorclip.com
Description: เขียน Plugin แบบ  Short Code Attribute Function
Version: 1.0
Author: Weerawat Chaleuiphot
Author URI:  http://www.tutorclip.com
License: GPL2
*/


add_shortcode( 'gmap', 'tc_create_map' );

function tc_create_map($attr, $address){
	// Set map default size
    $defaults = array(
        'width'  => '650',
        'height' => '500',
        'zoom'   => 16,
    );
	
	extract(shortcode_atts($defaults, $attr));
	
	$address_map = tc_getmap_address($address);
    
    // ตรวจสอบ ค่าของ  lat long โดยถ้าไม่มีค่า ให้ส่งเป็นค่าว่างออกไป
    if( !$address_map )
        return '';
        
    //  set ตัวแปร $output 
    $output = '';
        
    // กำหนดให้ ค่า Array lat,long เป็นตัวแปร
    extract( $address_map );
		
	// ตัดเครื่องหมายอักขระพิเศษออก
	$lat     = htmlspecialchars($lat);	
    $long    = htmlspecialchars($long);	
    $address = htmlspecialchars($address);	
    $zoom    = htmlspecialchars($zoom);	
    $width   = htmlspecialchars($width);	
    $height  = htmlspecialchars($height);
	
	
	// สร้างชื่อ  Object ของแผ่นที่ ขึ้นมาโดยให้ชื่อมีความแตกต่างกันโดยลักษณะของที่อยู่
    $map_id = 'tc_map_'.md5($address);
    	
    // Add the Google Maps javascript only once per page
    static $script_added = false;
    if( $script_added == false ) {
        $output .= '<script type="text/javascript"
        src="http://maps.google.com/maps/api/js?sensor=false"></script>';
        $script_added = true;
    }
    
    // Add the map specific code
    $output .= <<<CODE
    <div id="$map_id"></div>
    
    <script type="text/javascript">
    function generate_$map_id() {
        var latlng = new google.maps.LatLng( $lat, $long );
        var options = {
            zoom: $zoom,
            center: latlng,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        }

        var map = new google.maps.Map(
            document.getElementById("$map_id"),
            options
        );

        var legend = '<div class="map_legend"><p> $address </p></div>';

        var infowindow = new google.maps.InfoWindow({
            content: legend,
        });

        var marker = new google.maps.Marker({
            position: latlng,
            map: map,
        });
        
        google.maps.event.addListener(marker, 'click', function() {
            infowindow.open(map,marker);
        });

    }

    generate_$map_id();
    
    </script>
    
    <style type"text/css">
    .map_legend{
        width:200px;
        max-height:200px;
        min-height:100px;
    }
    #$map_id {
        width: {$width}px;
        height: {$height}px;
    }
    </style>
    
CODE;

    return $output;
	
};

function tc_getmap_address($address) {
	// Current post id
    global $id;
	
	// Check if we already have this coordinates in the database
    $saved = get_post_meta( $id, 'tc_addresses' );
    foreach( (array)$saved as $_saved ) {
        if( isset( $_saved['address'] ) && $_saved['address'] == $address ) {
            extract( $_saved );
            return compact( 'lat', 'long' );
        }
    }
	
	$coords = tc_getlocationlatlon($address);
    if( !$coords )
        return false;
		
	// Cache result in a post meta data
    add_post_meta( $id, 'tc_addresses', array(
        'address' => $address,
        'lat' => $coords['lat'],
        'long' => $coords['long']
        )
    );
    
	// Return array with lat and long
    extract( $coords );
    return compact( 'lat', 'long' );
}

function tc_getlocationlatlon($address) {
    // Make Google Geocoding API URL
    $map_url = 'http://maps.google.com/maps/api/geocode/json?address=';
    $map_url .= urlencode($address).'&sensor=false';
    
    // Send GET request
    $request = wp_remote_get( $map_url );

    // Get the JSON object
    $json = wp_remote_retrieve_body( $request );

    // Make sure the request was succesful or return false
    if( empty( $json ) )
        return false;
    
    // Decode the JSON object
    $json = json_decode( $json );

    // Get coordinates
    $lat = $json->results[0]->geometry->location->lat;    //latitude
    $long = $json->results[0]->geometry->location->lng;   //longitude
    
    // Return array of latitude & longitude
    return compact( 'lat', 'long' );
}

?>