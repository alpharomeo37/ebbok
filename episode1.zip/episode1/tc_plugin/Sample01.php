<?php
/*
 Plugin Name: Tutor Clip Sample 01
 Plugin URI: http://www.tutorclip.com
 Description: เริ่มต้นเขียน Plugin เป็นครั้งแรก
 Version: 1.0
 Author: Weerawat Chaleuiphot
 Author URI:  http://www.tutorclip.com
 License: GPL2
 
*/

//1. plugin activation
register_activation_hook(__FILE__,'tc_create_update_table');

function tc_create_update_table(){
	error_log('Plugin Activate');
}
//2. plugin deactivation
register_deactivation_hook(__FILE__,'tc_deactivation');

function tc_deactivation(){
	error_log('Plugin Deactivate');
}

//3. plugin remove

?>