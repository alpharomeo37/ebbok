<?php
//คำสั่งนี้จะทำงานก็ต่อเมื่อ file plugin ได้มีการเรียกใช้งานในการถอนการติดตั้ง  "Uninstall"
if ( !defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit();	
	// Delete option from options table
	delete_option( ‘Tutor_Clip_Sample_01_options’ );
	//remove any additional options and custom tables
}
    
?>
