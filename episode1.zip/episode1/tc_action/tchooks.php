<?php
/* 
Plugin Name: TC Hooks 
Plugin URI: http://www.tutorclip.com
Description: เขียน Plugin แบบ  Action Hooks
Version: 1.0
Author: Weerawat Chaleuiphot
Author URI:  http://www.tutorclip.com
License: GPL2
*/
    add_action('wp_footer',function(){
    echo 'Hello this post from my footer !!';
});
?>
