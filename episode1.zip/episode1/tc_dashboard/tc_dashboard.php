<?php
/* 
Plugin Name: TC Dash Board Widget
Plugin URI: http://www.tutorclip.com
Description: เขียน  Dash Board แสดงใน Word Press
Version: 1.0
Author: Weerawat Chaleuiphot
Author URI:  http://www.tutorclip.com
License: GPL2
*/

add_action('wp_dashboard_setup','tc_add_dashboard_widgets');

function tc_add_dashboard_widgets(){
	// Refrence : https://codex.wordpress.org/Function_Reference/wp_add_dashboard_widget
	wp_add_dashboard_widget('tc_dashboard_widget','<strong>Last User Access Web Site</strong>','tc_display_dashboard');
}

function tc_display_dashboard(){	
	$args = array(
		'orderby' => 'login',
		'order'   => 'ASC' // ASC or DESC 
	);
	$user_query = new WP_User_Query($args);
	
	// User Loop
	if (!empty( $user_query->results ) ) {
		foreach ( $user_query->results as $user ) {
			echo '<p><strong>Display name : </strong>' . $user->display_name . '</p>';
			echo '<p><strong>First name : </strong>' . $user->first_name . '</p>';
			echo '<p><strong>last name : </strong>' . $user->last_name . '</p>';
			echo '<p><strong>User register at : </strong>' . $user->user_registered.'</p>';
			echo '<hr>';
		}
	} else {
		echo 'No users found.';
	}		
}


?>