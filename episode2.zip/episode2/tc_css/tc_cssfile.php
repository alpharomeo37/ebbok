<?pbp
/* 
Plugin Name: TC Call CSS File 
Plugin URI: http://www.tutorclip.com
Description: เขียน  Plugin เรียกใช้  CSS file ลงไปในส่วนของ  Wordpress 
Version: 1.0
Author: Weerawat Chaleuiphot
Author URI:  http://www.tutorclip.com
License: GPL2
*/ 

// register widget
add_action('widgets_init','tc_widget_init');  

// add admin settingd
add_action('admin_init', 'tc_admin_init');
add_action('admin_menu','tc_plugin_menu');

// initial widget
function tc_widget_init(){
	register_widget(tc_widget_class); 	
}

// contruct class tc_widget_class
class tc_widget_class extends WP_Widget{
	function tc_widget_class(){
		$widget_options = array(
			'calssname' => 'tc_css_class',  // for css
			'description' => 'Add item to list'
		);
		
		this->WP_Widget('tc_calss_id','tc_list',$widget_options);
	}
	
	// Show widget form in Appearenace => Widgets
	function form($instance){
		$default = array('title'=>'tc_list');
		$instance = wp_parse_args((array),$instance,$default);
		$title = esc_attr($instance['title']);
		echo '<p>Tiile <input class="widefat" name="'.$this->get_field_name('title').'"type="input"></p>';
	}
	
	// Save widget form
	function update($new_instance,$old_instance){
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']); 
		return $instance;
	}
	
	// Show Widgets
	function widget($args,$instance){
		extract($args);
		$title = apply_filters('widget_title',$instance['title']);
		
		// show if single post
		if(is_single()){
			echo $before_widget;
			echo $before_title_title.$title.$after_title;
			echo '<span id="tc_add_list_div"><a id="tc_add_list_div" href=""> Add list</a></span>';
			echo $after_widget;
		}
	}
	
}

// Add plugin admin settins
function tc_admin_init(){
	register_setting('tc_group','tc_dashboard_title');
	register_setting('tc_group','tc_number_of_items ');
	
}

function tc_plugin_menu(){
	add_option_page('TC_Add_List','TC List','manage_options','TCList','tc_group');
	
}


?>