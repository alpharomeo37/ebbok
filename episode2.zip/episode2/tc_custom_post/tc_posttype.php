<?php
/*
Plugin Name: TC Custom Post Types
Plugin URI: http://www.tutorclip.com
Description: เขียน  Custom Post Types แบบที่เราต้องการ
Version: 1.0
Author: Weerawat Chaleuiphot
Author URI:  http://www.tutorclip.com
License: GPL2
*/

class TC_EBook_Post_Type{
    public function __construct()
    {
         $this->register_post_type();
         $this->taxonomies();
         $this->metaboxes();
    }

    public function register_post_type()
    {
        $args = array(
            'labels' => array(
                'name' => 'EBook',
                'singular_name' => 'EBook',
                'add_new_item' => 'Add New EBook',
                'edit_item' => 'Edit Item',
                'new_item' => 'View EBook',
                'search_items' => 'Search EBooks',
                'not_found' => 'No EBooks Found',
                'not_found_in_trash' => 'No EBooks Found in Trash'
            ),
            'query_var' => 'ebooks',
            'rewrite' => array(
              'slug' => 'ebooks/',
            ),
            'public' => true,
            'menu_position' => 25,
            'menu_icon' => admin_url().'images/media-button-other.gif',
            'supports' => array(
                'title',
                'thumbnail',
                'excerpt',
                'custom-fields'
            )
        );
        register_post_type('tc_ebook',$args);
    }

    public function taxonomies(){
        $taxonomies = array();

        $taxonomies['ebook'] = array(
            'hierarchical' => true,
            'query_var' => 'ebbok_wordpress',
            'rewrite' => array(
                'slug' => 'ebook/wordpress'
            ),
            'labels' => array(
                'name' => 'EBook-Plugin',
                'singular_name' => 'EBook-Plugin',
                'edit_item' => 'Edit EBook-Plugin',
                'update_item' => 'Update EBook-Plugin',
                'add_new_item' => 'Add New EBook-Plugin',
                'new_item_name' => 'Add New EBook',
                'all_items' => 'All EBook',
                'search_items' => 'Search EBook-Plugin',
                'popular_items' => 'Popular EBook',
                'separate_items_with_commas' => 'Separate ebook with commas',
                'add_or_remove_items' => 'Add or remove Ebook',
                'choose_from_most_used' => 'Choose from most used',
                'not_found' => 'No EBooks Found'
            )
        );

        $taxonomies['publisher'] = array(
            'hierarchical' => true,
            'query_var' => 'ebbok_publisher',
            'rewrite' => array(
                'slug' => 'ebook/publisher'
         ),
            'labels' => array(
                'name' => 'Publisher',
                'singular_name' => 'Publisher',
                'edit_item' => 'Edit Publisher',
                'update_item' => 'Update Publisher',
                'add_new_item' => 'Add New Publisher',
                'new_item_name' => 'Add New Publisher',
                'all_items' => 'All Publisher',
                'search_items' => 'Search Publisher',
                'popular_items' => 'Popular Publisher',
                'separate_items_with_commas' => 'Separate publisher with commas',
                'add_or_remove_items' => 'Add or remove Publisher',
                'choose_from_most_used' => 'Choose from most used',
                'not_found' => 'No Publisher Found'
            )
        );
        $this->register_all_taxonomies($taxonomies);
    }

    public function register_all_taxonomies($taxonomies)
    {
        foreach ($taxonomies as $name => $arr) {
            register_taxonomy($name,array('tc_ebook'),$arr);
        }
    }

    public  function metaboxes(){
        add_action('add_meta_boxes','metabox_pages');

        function metabox_pages(){
            // cs_id, title, cb func, page, priority, cb func aruments
            add_meta_box('tc_ebook_pages','Ebook Pages','ebook_pages','tc_ebook');
        }

        function ebook_pages($post){
            $pages = get_post_meta($post->ID,'tc_ebook_pages',true);
            ?>
                <label for="tc_ebook_pages">Pages :</label>
                <input type="text" class="widefat" name="tc_ebook_pages" id="tc_ebook_pages" value="<?php echo esc_attr($pages); ?>" />
            <?php

        }

        add_action('save_post','metabox_pages_save');

        function metabox_pages_save($id)
        {
            if (isset($_POST['tc_ebook_pages'])) {
                update_post_meta(
                    $id,
                    'tc_ebook_pages',
                    strip_tags($_POST['tc_ebook_pages'])
                );
            }
        }
    }
}


add_action('init','tc_ebook_init');

function tc_ebook_init(){
    new TC_EBook_Post_Type();
}

?>