<?php
/* 
Plugin Name: TC Admin Menu
Plugin URI: http://www.tutorclip.com
Description: เขียน  menu เพิ่มลงไปในส่วนของ Menu Wordpress ที่มีอยู่
Version: 1.0
Author: Weerawat Chaleuiphot
Author URI:  http://www.tutorclip.com
License: GPL2
*/
// Refer : https://codex.wordpress.org/Plugin_API/Action_Reference/admin_menu
add_action('admin_menu','tc_admin_menu');
// Refer : https://codex.wordpress.org/Plugin_API/Action_Reference/admin_init
add_action('admin_init','tc_admin_init');

function tc_admin_menu(){
	// Refer : https://codex.wordpress.org/Function_Reference/add_options_page
	add_options_page('TC Menu Setting','TC Menu','manage_options','tc_menu','tc_menu_option');
}

function tc_admin_init(){
	// Refer : https://codex.wordpress.org/Function_Reference/register_setting
	register_setting('tc_menu_group','tc_dashboard_title');
	register_setting('tc_menu_group','tc_number_of_items');
}
// Show User Interface in here
function tc_menu_option(){
	
?>
<!-- Code HTML/JavaScript in here -->
	<div class="wrap">
		<?php screen_icon('plugins'); ?>		
		<h2>TC Menu Option</h2>
		
		<form action="options.php" method="post">
			<?php 
				// Refer : https://codex.wordpress.org/Function_Reference/settings_fields
				settings_fields('tc_menu_group'); 
			?>			
			<?php 
				// Refer : https://codex.wordpress.org/Function_Reference/do_settings_fields
				@do_settings_fields('tc_menu_group'); 
			?>
			<table class="from-table">
				<tr valign="top">
					<th scope="row"><label for="tc_dashboard_title">Dash board Widgets</label></th>
					<td>
						<input type="text" name="tc_dashboard_title" id="tc_dashboard_title" value="<?php echo get_option('tc_dashboard_title'); ?>" />
						<br/><small>help text for this field</small>
					</td>
				</tr>
				<tr align="top">
					<th scope="row"><label for="tc_number_of_items">Number of items to show</label></th>
					<td>
						<input type="text" name="tc_number_of_items" id="tc_number_of_items" value="<?php echo get_option('tc_number_of_items'); ?>" />
						<br/><small>help text for this field</small>
					</td>
				</tr>
			</table><?php @submit_button(); ?>	
		</form>
	</div>
<?php	
	
}
?>