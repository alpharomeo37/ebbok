<?php
/* 
Plugin Name: TC SubMenu Page 
Plugin URI: http://www.tutorclip.com
Description: เขียน  submenu page ลงไปในส่วนของ  Wordpress 
Version: 1.0
Author: Weerawat Chaleuiphot
Author URI:  http://www.tutorclip.com
License: GPL2
*/

add_action('admin_menu','tc_menu_admin');

function tc_menu_admin(){
    add_menu_page('TutorClip Admin Menu',
                                'TutorClip Menu',
                                'manage_options',
                                __FILE__,
                                'tc_menu_admin_setting_page',
                                plugins_url('icons32.png',__FILE__),
                                11);
	add_submenu_page(__FILE__,'TutorClip About','About menu','manage_options','tc_menupage_about','tc_help_function');								
}

?>