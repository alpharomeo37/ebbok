<?php
/* 
Plugin Name: TC Menu Page
Plugin URI: http://www.tutorclip.com
Description: เขียน  menu page ลงไปในส่วนของ  Wordpress 
Version: 1.0
Author: Weerawat Chaleuiphot
Author URI:  http://www.tutorclip.com
License: GPL2
*/

add_action('admin_menu','tc_menu_admin');

function tc_menu_admin(){
    add_menu_page('TutorClip Admin Menu',
                                'TutorClip Menu',
                                'manage_options',
                                __FILE__,
                                'tc_menu_admin_setting_page',
                                plugins_url('icons32.png',__FILE__),
                                11);
}

?>