<?php
/* 
Plugin Name: TC Role
Plugin URI: http://www.tutorclip.com
Description: เขียน Plugin add role
Version: 1.0
Author: Weerawat Chaleuiphot
Author URI:  http://www.tutorclip.com
License: GPL2
*/

function add_roles_sample(){
		add_role('Sample_Role_TutorClip','Sample Role TutorClip',
			array(
				'read' => 'true',
				'edit_pages' => 'true',
				'delete_pages' => 'true'
			)
		);
}

register_activation_hook( __FILE__, 'add_roles_sample' );

?>