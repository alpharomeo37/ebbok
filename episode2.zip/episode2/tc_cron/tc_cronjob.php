<?php
/* 
Plugin Name: TC Cron Job
Plugin URI: http://www.tutorclip.com
Description: ตัวอย่างการทำงานของ Cron Job ในระบบ Wordpress
Version: 1.0
Author: Weerawat Chaleuiphot
Author URI:  http://www.tutorclip.com
License: GPL2
*/

add_action('admin_menu','tc_cron_menu');

function tc_cron_menu() {
	//create cron example settings page
	add_options_page( 'Cron Example Settings', 'View Comment List','manage_options', 'tc-cron', 'tc_cron_settings');
}

function tc_cron_settings(){
		
	echo '<DIV><h1>Get list all comment</h1></DIV>';
	// get all user in wordpress
	$wp_user_search = get_users('order=ASC');
	echo '<table border="0" cellpadding="5" cellspacing="5">';
	echo('<tr><td>User ID</td><td>User Login</td><td>User Name</td></tr>');
	
	foreach ( $wp_user_search as $user ) {
		$user_id       = (int) $user->ID;
		$user_login    = stripslashes($user->user_login);
		$display_name  = stripslashes($user->display_name);
		echo('<tr><td>'.$user_id.'</td><td>'.$user_login.'</td><td>'.$display_name.'</td></tr>');	
		
		// get all comment by user id
		$arg_comment = array('user_id' => $user_id,'order' => 'DESC');
		$all_comment = get_comments($arg_comment);
		foreach($all_comment as $comment){
				echo('<tr><td colspan="3"><b>Comment Message : </b>' . $comment->comment_content.'</td></tr>');
		}
	}
	echo '</table>';
}
		
register_activation_hook(__FILE__, 'tc_cron_active');


add_action('tc_event_job', 'tc_cron_process');

function tc_cron_active() {
	wp_schedule_event(time(), 'hourly', 'tc_event_job');	
}

function tc_cron_process() {
	// do something every hour
	$email_msg = "";
	$email_msg = '<DIV><h1>Get list all comment</h1></DIV>';
	// get all user in wordpress
	$wp_user_search = get_users('order=ASC');
	$email_msg .= '<table border="0" cellpadding="5" cellspacing="5">';
	$email_msg .= '<tr><td>User ID</td><td>User Login</td><td>User Name</td></tr>';
	
	foreach ( $wp_user_search as $user ) {
		$user_id       = (int) $user->ID;
		$user_login    = stripslashes($user->user_login);
		$display_name  = stripslashes($user->display_name);
		$email_msg .= '<tr><td>'.$user_id.'</td><td>'.$user_login.'</td><td>'.$display_name.'</td></tr>';	
		
		// get all comment by user id
		$arg_comment = array('user_id' => $user_id,'order' => 'DESC');
		$all_comment = get_comments($arg_comment);
		foreach($all_comment as $comment){
				$email_msg += '<tr><td colspan="3"><b>Comment Message : </b>' . $comment->comment_content.'</td></tr>';
		}
	}
	$email_msg .= '</table>';
	$headers = array('Content-Type: text/html; charset=UTF-8');
	$email_to = get_option('admin_email');
	$email_subject = "Log Comment in Wordpress ";
	
	wp_mail($email_to,$email_subject,$email_msg,$headers);
}

?>