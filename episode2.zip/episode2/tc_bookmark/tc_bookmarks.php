<?php
/* 
Plugin Name: TC Bookmark Post
Plugin URI: http://www.tutorclip.com
Description: เขียน Plugin Bookmark Post ตัวอย่างการใช้งาน User Meta Data
Version: 1.0
Author: Weerawat Chaleuiphot
Author URI:  http://www.tutorclip.com
License: GPL2
*/


add_action('show_user_profile', 'tc_bookmark_post');
add_action('edit_user_profile', 'tc_bookmark_post');


function tc_bookmark_post($current_user){
	
	// Get current user bookmark post
	$bookmark_post = get_user_meta($current_user->ID,'bookmark_post',true);
	
	$post_name = get_posts(array('numberposts' => -1));	

?>

<h3>Bookmark Current Post</h3>
<table class="form-table">
		<tr>
			<th><label for="book_post">Bookmark Post</label></th>
			<td>
				<select name="bookmark_post" id="bookmark_post" >
					<option value=""></option>
						<?php foreach($post_name as $post) { ?>
						<option value="<?php echo esc_attr($post->ID); ?>"
						<?php selected( $bookmark_post, $post->ID); ?>>
							<?php echo esc_html($post->post_title); ?>
						<?php } ?>
					</option>
					
				</select>
				<br />
					<span class="description"> Select your bookmark post. </span>
			</td>			
		</tr>
</table>

<?php }  // end function tc_bookmark_post

	/* Add the update function to the user update hooks. */
	add_action('personal_options_update', 'tc_bookmark_post_update');
	add_action('edit_user_profile_update', 'tc_bookmark_post_update');
	
	/* Function for updating the user’s bookmark post. */
	function tc_bookmark_post_update($current_user_id){
		
		if (!current_user_can('edit_user', $current_user_id))
			return false;
		
		/* Only accept numbers 0-9 since it’s a post ID. */
		$bookmark_post = preg_replace("/[^0-9]/", '',$_POST['bookmark_post']);
		
		/* Update the user’s bookmark post. */
		update_user_meta($current_user_id, 'bookmark_post', $bookmark_post);

	}
?>
<?php
	/* Get the user’s Bookmark post (ID). */
	$post_id = get_the_ID();
	$bookmark_post = get_user_meta($post_id,'bookmark_post', true);
	/* Check if the Bookmark post is set. */
	if (!empty($bookmark_post)) {
		$post = get_post($bookmark_post);
		/* Display the post title. */
		echo $post-> post_title;
	}
?>