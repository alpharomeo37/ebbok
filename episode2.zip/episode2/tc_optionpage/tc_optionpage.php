<?php
/* 
Plugin Name: TC Option Page
Plugin URI: http://www.tutorclip.com
Description: เขียน  option page ลงไปในส่วนของ  Wordpress 
Version: 1.0
Author: Weerawat Chaleuiphot
Author URI:  http://www.tutorclip.com
License: GPL2
*/

add_action('admin_menu','tc_menu_option_page');

function tc_menu_option_page(){
	add_options_page('Tutorclip Option',
					 'TutorClip Page Option',
					 'manage_options',
					 __FILE__,
					 'Option_page_setting');
    									
}

?>