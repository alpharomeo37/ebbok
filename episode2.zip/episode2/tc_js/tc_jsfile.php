<?php
/*
Plugin Name: TC Menu JavaScript File
Plugin URI: http://www.tutorclip.com
Description: เขียน  Plugin เรียกใช้  JavaScript file ลงไปในส่วนของ  Wordpress
Version: 1.0
Author: Weerawat Chaleuiphot
Author URI:  http://www.tutorclip.com
License: GPL2
*/


add_action('admin_menu','tc_admin_js_menu');

add_action('admin_init','tc_admin_js_init');

function tc_admin_js_menu(){
    // Refer : https://codex.wordpress.org/Function_Reference/add_options_page
    add_options_page('TC Menu JS Setting','TC Menu JS','manage_options','tc_menu_js','tc_menu_js_option');
}


function tc_admin_js_init(){
    // Refer : https://codex.wordpress.org/Function_Reference/register_setting
    register_setting('tc_menu_group','tc_script_of_items');
    wp_enqueue_script( 'tc_js_script', plugin_dir_url( __FILE__ ) . 'js/myscript.js', null, null );
}

function tc_menu_js_option(){
?>
    <div class="tc-container">
        <?php screen_icon('plugins'); ?>
        <h2>TC Menu JavaScript Option</h2>
        <div  class="tc-panel">
            <form action="options.php" method="post">
                <?php
                // Refer : https://codex.wordpress.org/Function_Reference/settings_fields
                settings_fields('tc_menu_group');
                ?>
                <?php
                // Refer : https://codex.wordpress.org/Function_Reference/do_settings_fields
                @do_settings_fields('tc_menu_group');
                ?>
                <table class="w3-table">
                    <tr align="top">
                        <th scope="row"><label for="tc_script_of_items">Java Script Box :</label></th>
                        <td>
                            <button type="button" onclick="messasebox()">Click Me!</button>
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
<?php
}

?>